﻿#define _CRT_SECURE_NO_WARNINGS
#define _WIN32_WINNT 0x0601
#pragma warning(disable: 28251)
#pragma warning(disable: 4566)
#pragma comment(lib, "msimg32.lib")

#include <Windows.h>
#include <Shlwapi.h>
#include <iostream>
#include <string>
#include <vector>
#include <atomic>
#include <thread>
#include <cmath>
#include <chrono>
#include <locale.h>
#include <functional>
#include <CommCtrl.h>

#pragma comment(lib, "user32.lib")
#pragma comment(lib, "Shlwapi.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "ComCtl32.lib")

// 工具函数、AI模型、文本清洗 的头文件
#include "utils/utils.h"
#include "model/model.h"
#include "clean/clean.h"

// ======================== 全局变量 ========================
// 程序是否正在运行
std::atomic<bool> g_is_running(false);
// 目标窗口句柄（要操作的软件窗口）
HWND g_target_hwnd = NULL;
// 可调整的相似度阈值（由右下角小按钮控制）
std::atomic<float> g_similarity_threshold(0.7f);
// 模板文本的向量编码
std::vector<float> g_template_emb;
// 主线程句柄
HANDLE g_main_thread = NULL;
// 上一次获取的文本（用于去重）
std::wstring g_last_raw;

// 界面字体
HFONT g_font = NULL;
HFONT g_small_font = NULL; // 小字按钮字体
// 相似度显示文本控件句柄
HWND g_hwnd_similarity = NULL;
// 当前计算出的相似度
std::atomic<float> g_current_sim = 0.0f;
// 暂停标志：true 时不操作目标窗口，防止遮挡弹窗
std::atomic<bool> g_paused(false);
// 刚滚动标志：跳过下一次自动点击，避免双击
std::atomic<bool> g_just_scrolled(false);

// ======================== 功能函数 ========================

// 等待光标到达目标点（容差 3 像素），超时返回 false
static bool WaitForCursorAt(int targetX, int targetY, int timeoutMs = 500)
{
    POINT p;
    int waited = 0;
    const int step = 20;
    while (waited < timeoutMs) {
        if (GetCursorPos(&p)) {
            int dx = p.x - targetX;
            int dy = p.y - targetY;
            if ((dx * dx + dy * dy) <= 9) return true; // 3x3像素范围内
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(step));
        waited += step;
    }
    return false;
}

// 获取程序 exe 所在目录
static std::wstring GetExeDir()
{
    wchar_t path[MAX_PATH] = { 0 };
    GetModuleFileNameW(NULL, path, MAX_PATH);
    PathRemoveFileSpecW(path); // 去掉文件名，只留目录
    return path;
}

// 打开模板文件（用记事本打开 template.txt）
static void OpenTemplateFile()
{
    std::wstring fullPath = GetExeDir() + L"\\data\\template.txt";
    ShellExecuteW(NULL, L"open", L"notepad.exe", fullPath.c_str(), NULL, SW_SHOWNORMAL);
}

// 弹出阈值调整对话框
// 先声明 UpdateSimilarityDisplay 原型，PromptChangeThreshold 会调用它
static void UpdateSimilarityDisplay(float sim);

// 弹出窗口调整相似度阈值（±0.05）
static void PromptChangeThreshold(HWND parent)
{
    // 弹窗选择：加0.05 / 减0.05 / 取消
    int ret = MessageBoxW(parent,
        L"选择阈值调整：是 = +0.05   否 = -0.05\n(当前阈值将四舍五入并限制在 [0,1])",
        L"调整相似度阈值",
        MB_YESNOCANCEL | MB_ICONQUESTION);

    if (ret == IDYES) {
        float v = g_similarity_threshold.load();
        v += 0.05f;
        if (v > 1.0f) v = 1.0f;
        g_similarity_threshold = v;
    }
    else if (ret == IDNO) {
        float v = g_similarity_threshold.load();
        v -= 0.05f;
        if (v < 0.0f) v = 0.0f;
        g_similarity_threshold = v;
    }
    // 更新界面显示
    UpdateSimilarityDisplay(g_current_sim);
}

// 更新界面上的相似度与阈值显示
static void UpdateSimilarityDisplay(float sim)
{
    if (!g_hwnd_similarity) return;
    wchar_t buf[64] = { 0 };
    swprintf_s(buf, L"当前相似度：%.4f  |  阈值：%.4f", sim, g_similarity_threshold.load());
    SetWindowTextW(g_hwnd_similarity, buf);
}

// ======================== 核心检测流程 ========================

// 快速预检：激活窗口 → 复制文本 → 基础校验
static bool QuickPrecheck(std::wstring& out_text, size_t min_len = 30)
{
    out_text.clear();
    if (!g_target_hwnd) return false;

    // 带运行状态检查的延时（中途停止则退出）
    auto SleepWithCheck = [](int ms)->bool {
        const int step = 50;
        int waited = 0;
        while (waited < ms) {
            if (!g_is_running) return false;
            int cur = (ms - waited) < step ? (ms - waited) : step;
            std::this_thread::sleep_for(std::chrono::milliseconds(cur));
            waited += cur;
        }
        return true;
        };

    // 激活目标窗口
    SetForegroundWindow(g_target_hwnd);
    SetFocus(g_target_hwnd);
    if (!SleepWithCheck(100)) return false;

    // 移动鼠标到窗口右上1/3处
    MoveMouseToWindowRightTopThird(g_target_hwnd);
    // 如果刚滚动过，跳过点击（防止双击）
    if (g_just_scrolled.exchange(false)) {
        // 等待鼠标稳定
        RECT r; GetWindowRect(g_target_hwnd, &r);
        int tx = r.right - ((r.right - r.left) / 40);
        int ty = r.top + (r.bottom - r.top) / 3;
        WaitForCursorAt(tx, ty, 300);
    }
    else {
        LeftClickMouse(); // 点击激活内容
    }

    // 全选→复制
    CtrlA_Only();
    if (!SleepWithCheck(3000)) return false;
    ResetClipboard();
    CtrlC_Only();
    if (!SleepWithCheck(300)) return false;

    // 读取剪贴板文本
    std::wstring raw;
    if (!ReadTextFromClipboard(raw) || raw.empty()) {
        DebugLog("[INFO] 快速预检：剪贴板为空");
        return false;
    }

    // 和上一次内容一样，跳过（去重）
    if (!g_last_raw.empty() && g_last_raw == raw) {
        DebugLog("[INFO] 快速预检：与上次内容相同，跳过");
        return false;
    }
    g_last_raw = raw;

    out_text = raw;
    // 文本太短，无效
    if (raw.size() < min_len) {
        DebugLog("[INFO] 快速预检：文本长度不足 %d，当前：%d", (int)min_len, (int)raw.size());
        return false;
    }

    // 保存原始文本样本（用于调试）
    {
        static int raw_sample_count = 0;
        raw_sample_count++;
        std::wstring exe_dir = GetExeDir();
        std::wstring raw_dir = exe_dir + L"\\data\\raw";
        CreateDirectoryW(raw_dir.c_str(), NULL);

        wchar_t raw_file[MAX_PATH];
        swprintf_s(raw_file, MAX_PATH, L"%s\\sample_%03d.txt", raw_dir.c_str(), raw_sample_count);

        FILE* f = nullptr;
        if (_wfopen_s(&f, raw_file, L"wb") == 0 && f) {
            const unsigned char bom[] = { 0xEF, 0xBB, 0xBF };
            fwrite(bom, 1, sizeof(bom), f);

            int utf8_len = WideCharToMultiByte(CP_UTF8, 0, raw.c_str(), -1, NULL, 0, NULL, NULL);
            if (utf8_len > 0) {
                std::string utf8_str(utf8_len - 1, '\0');
                WideCharToMultiByte(CP_UTF8, 0, raw.c_str(), -1, &utf8_str[0], utf8_len, NULL, NULL);
                fwrite(utf8_str.c_str(), 1, utf8_str.size(), f);
            }
            fclose(f);
        }
    }
    return true;
}

// 详细检测：清洗文本 → 向量化 → 计算相似度
static bool DetailedCheck(const std::wstring& raw_text)
{
    if (raw_text.empty()) return false;
    // 清洗文本（去掉广告、符号、空格等干扰内容）
    std::wstring cleaned = clean_business_text(raw_text);

    if (cleaned.empty()) {
        DebugLog("[INFO] 详细检测：清洗后文本为空");
        return false;
    }

    // 保存清洗后文本（调试用）
    {
        static int cnt = 0; cnt++;
        std::wstring dir = GetExeDir() + L"\\data\\cleaned";
        CreateDirectoryW(dir.c_str(), NULL);

        wchar_t path[MAX_PATH];
        swprintf_s(path, L"%s\\sample_%03d.txt", dir.c_str(), cnt);

        FILE* f = nullptr;
        if (_wfopen_s(&f, path, L"wb") == 0 && f) {
            const unsigned char bom[] = { 0xEF, 0xBB, 0xBF };
            fwrite(bom, 1, sizeof(bom), f);

            int len = WideCharToMultiByte(CP_UTF8, 0, cleaned.c_str(), -1, NULL, 0, NULL, NULL);
            if (len > 0) {
                std::string s(len - 1, 0);
                WideCharToMultiByte(CP_UTF8, 0, cleaned.c_str(), -1, &s[0], len, NULL, NULL);
                fwrite(s.c_str(), 1, s.size(), f);
            }
            fclose(f);
        }
    }

    // 超长文本截断，避免模型处理超时
    if (cleaned.size() > 1024) cleaned = cleaned.substr(0, 1024);
    std::vector<float> emb;

    // 调用模型编码文本为向量
    if (!model_encode(cleaned, emb) || emb.empty() || g_template_emb.empty()) {
        DebugLog("[ERROR] 编码失败");
        return false;
    }

    // 计算与模板的相似度
    float sim = calc_similarity(emb, g_template_emb);
    g_current_sim = sim;
    UpdateSimilarityDisplay(sim);

    printf("[相似度] %.4f / %.4f\n", sim, g_similarity_threshold.load());
    fflush(stdout);

    // 返回是否匹配成功
    return sim >= g_similarity_threshold.load();
}

// ======================== 主循环线程 ========================
DWORD WINAPI MainLoopThread(LPVOID lpParam)
{
    DebugLog("[启动] 主循环");
    int cnt = 0;

    while (g_is_running) {
        cnt++;
        printf("\n==== 第 %d 轮 ====\n", cnt);

        std::wstring raw;
        // 第一步：快速预检获取文本
        bool ok = QuickPrecheck(raw);

        if (!ok) {
            if (!g_is_running) break;
            SetForegroundWindow(g_target_hwnd);
            SetFocus(g_target_hwnd);
            Sleep(100);

            // 暂停模式：不操作窗口，防止弹窗被遮挡
            if (g_paused) {
                Sleep(300);
                continue;
            }

            // 未找到：向下滚动，继续下一条
            MoveMouseToWindowCenter(g_target_hwnd);
            Sleep(100);
            MouseScrollDown();
            // 滚动后把鼠标移到右侧安全区
            MoveMouseToWindowRightTopThird(g_target_hwnd);
            RECT r; GetWindowRect(g_target_hwnd, &r);
            int width = r.right - r.left;
            int margin = max(8, width / 40);
            int tx = r.right - margin;
            int ty = r.top + (r.bottom - r.top) / 3;
            // 等待鼠标到位
            WaitForCursorAt(tx, ty, 300);
            // 等待界面稳定
            std::this_thread::sleep_for(std::chrono::milliseconds(1000));
            // 标记刚滚动，下次跳过点击
            g_just_scrolled = true;
            LeftClickMouse();
            Sleep(300);
            continue;
        }

        // 第二步：详细检测相似度
        bool match = DetailedCheck(raw);
        if (match) break; // 匹配成功，退出循环
        if (!g_is_running) break;

        // 未匹配：滚动到下一条
        SetForegroundWindow(g_target_hwnd);
        SetFocus(g_target_hwnd);
        Sleep(100);
        MoveMouseToWindowCenter(g_target_hwnd);
        Sleep(100);
        MouseScrollDown();
        MoveMouseToWindowRightTopThird(g_target_hwnd);
        RECT r; GetWindowRect(g_target_hwnd, &r);
        int width = r.right - r.left;
        int margin = max(8, width / 40);
        int tx = r.right - margin;
        int ty = r.top + (r.bottom - r.top) / 3;
        WaitForCursorAt(tx, ty, 300);
        std::this_thread::sleep_for(std::chrono::milliseconds(1000));
        g_just_scrolled = true;
        LeftClickMouse();
        Sleep(300);
    }

    // 结束后卸载模型、重置状态
    unload_model();
    g_is_running = false;
    printf("[结束]\n");
    return 0;
}

// ======================== 界面绘制（自定义按钮） ========================
void DrawMyButton(HWND btn, HDC hdc, LPDRAWITEMSTRUCT dis)
{
    RECT rc = dis->rcItem;
    bool is_pressed = (dis->itemState & ODS_SELECTED) != 0;
    int id = GetDlgCtrlID(btn);

    int offset = is_pressed ? 1 : 0; // 按下时文字偏移

    HFONT oldFont = (HFONT)SelectObject(hdc, g_font);
    SetBkMode(hdc, TRANSPARENT);

    // 开始按钮：蓝色
    if (id == 1001) {
        if (is_pressed) FillRect(hdc, &rc, CreateSolidBrush(RGB(0, 80, 150)));
        else FillRect(hdc, &rc, CreateSolidBrush(RGB(30, 120, 200)));
        SetTextColor(hdc, RGB(255, 255, 255));
    }
    // 停止按钮：红色
    else if (id == 1002) {
        if (is_pressed) FillRect(hdc, &rc, CreateSolidBrush(RGB(150, 20, 20)));
        else FillRect(hdc, &rc, CreateSolidBrush(RGB(200, 60, 60)));
        SetTextColor(hdc, RGB(255, 255, 255));
    }
    // 编辑模板按钮：灰色
    else if (id == 1003) {
        if (is_pressed) FillRect(hdc, &rc, CreateSolidBrush(RGB(160, 160, 160)));
        else FillRect(hdc, &rc, CreateSolidBrush(RGB(210, 210, 210)));
        SetTextColor(hdc, RGB(0, 0, 0));
    }

    // 绘制按钮文字
    wchar_t text[256];
    GetWindowTextW(btn, text, 256);
    RECT rcText = rc;
    OffsetRect(&rcText, offset, offset);
    DrawTextW(hdc, text, -1, &rcText, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

    // 绘制边框
    if (is_pressed) FrameRect(hdc, &rc, CreateSolidBrush(RGB(0, 0, 0)));
    else FrameRect(hdc, &rc, CreateSolidBrush(RGB(80, 80, 80)));

    SelectObject(hdc, oldFont);
}

// ======================== 窗口消息处理 ========================
LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
    case WM_CREATE:
        // 创建界面字体
        g_font = CreateFontW(25, 0, 0, 0, FW_BOLD, 0, 0, 0,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
            DEFAULT_QUALITY, DEFAULT_PITCH, L"Microsoft YaHei UI");
        // 小按钮字体
        g_small_font = CreateFontW(14, 0, 0, 0, FW_NORMAL, 0, 0, 0,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
            DEFAULT_QUALITY, DEFAULT_PITCH, L"Microsoft YaHei UI");
        break;

    case WM_DRAWITEM:
    {
        // 自绘按钮
        LPDRAWITEMSTRUCT dis = (LPDRAWITEMSTRUCT)lParam;
        DrawMyButton((HWND)dis->hwndItem, dis->hDC, dis);
        return TRUE;
    }

    case WM_COMMAND:
    {
        int id = LOWORD(wParam);
        // 按钮1：开始检测
        if (id == 1001) {
            if (g_is_running) break;
            DebugLog("0.2秒后锁定窗口...");
            Sleep(1000);
            // 获取鼠标当前指向的窗口作为目标
            POINT pt; GetCursorPos(&pt);
            g_target_hwnd = WindowFromPoint(pt);
            if (!g_target_hwnd) { DebugLog("锁定失败"); break; }
            DebugLog("已锁定");

            // 加载AI模型
            std::wstring model = GetExeDir() + L"\\models\\model.onnx";
            if (!load_model(model.c_str())) { DebugLog("模型加载失败"); break; }

            // 读取并编码模板文本
            std::wstring tpl = ReadTemplateFile();
            std::wstring ctpl = clean_business_text(tpl);
            if (!model_encode(ctpl, g_template_emb) || g_template_emb.empty()) {
                DebugLog("模板失败"); unload_model(); break;
            }

            // 重置状态并启动线程
            g_last_raw.clear();
            g_current_sim = 0;
            UpdateSimilarityDisplay(0);
            g_is_running = true;
            g_paused = false;
            g_main_thread = CreateThread(0, 0, MainLoopThread, 0, 0, 0);
        }
        // 按钮2：停止检测
        else if (id == 1002) {
            g_is_running = false;
            // 等待线程结束
            if (g_main_thread) { WaitForSingleObject(g_main_thread, 2000); CloseHandle(g_main_thread); g_main_thread = NULL; }
            unload_model();
            g_current_sim = 0;
            UpdateSimilarityDisplay(0);
        }
        // 按钮3：打开模板文件
        else if (id == 1003) {
            OpenTemplateFile();
        }
        // 按钮4：调整阈值
        else if (id == 1004) {
            // 调整期间暂停操作，防止弹窗被遮挡
            bool was_running = g_is_running;
            if (was_running) {
                g_paused = true;
            }
            PromptChangeThreshold(hWnd);
            if (was_running) {
                std::this_thread::sleep_for(std::chrono::milliseconds(200));
                g_paused = false;
            }
        }
        break;
    }

    // 静态文本背景透明
    case WM_CTLCOLORSTATIC:
    {
        HDC hdc = (HDC)wParam;
        SetBkMode(hdc, TRANSPARENT);
        SetTextColor(hdc, GetSysColor(COLOR_WINDOWTEXT));
        return (LRESULT)GetSysColorBrush(COLOR_WINDOW);
    }

    // 窗口销毁：释放资源
    case WM_DESTROY:
        if (g_font) DeleteObject(g_font);
        if (g_small_font) DeleteObject(g_small_font);
        PostQuitMessage(0);
        break;

    default:
        return DefWindowProc(hWnd, msg, wParam, lParam);
    }
    return 0;
}

// ======================== 程序入口 ========================
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrev, LPSTR lpCmd, int nCmdShow)
{
    INITCOMMONCONTROLSEX icex;
    icex.dwSize = sizeof(INITCOMMONCONTROLSEX);
    icex.dwICC = ICC_STANDARD_CLASSES;
    InitCommonControlsEx(&icex);

    const wchar_t CLASS[] = L"MYWINDOW";
    WNDCLASSEX wc = { 0 };
    wc.cbSize = sizeof(WNDCLASSEX);
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS;
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);

    // 从exe目录加载图标 app.ico
    wc.hIcon = (HICON)LoadImageW(
        NULL,
        L"app.ico",
        IMAGE_ICON,
        32, 32,
        LR_LOADFROMFILE | LR_DEFAULTSIZE
    );
    wc.hIconSm = (HICON)LoadImageW(
        NULL,
        L"app.ico",
        IMAGE_ICON,
        16, 16,
        LR_LOADFROMFILE | LR_DEFAULTSIZE
    );

    // 加载失败则使用系统默认图标，防止崩溃
    if (!wc.hIcon) wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    if (!wc.hIconSm) wc.hIconSm = LoadIcon(NULL, IDI_APPLICATION);

    RegisterClassEx(&wc);

    // 创建主窗口
    HWND hWnd = CreateWindowExW(WS_EX_TOPMOST, CLASS,
        L"文本相似度自动检测 - 青春版",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
        100, 100, 525, 180,
        NULL, NULL, hInstance, NULL);

    // 创建三个主按钮
    CreateWindowW(L"BUTTON", L"开始检测", WS_VISIBLE | WS_CHILD | BS_OWNERDRAW,
        30, 30, 130, 50, hWnd, (HMENU)1001, hInstance, NULL);

    CreateWindowW(L"BUTTON", L"停止检测", WS_VISIBLE | WS_CHILD | BS_OWNERDRAW,
        190, 30, 130, 50, hWnd, (HMENU)1002, hInstance, NULL);

    CreateWindowW(L"BUTTON", L"编辑模板", WS_VISIBLE | WS_CHILD | BS_OWNERDRAW,
        350, 30, 130, 50, hWnd, (HMENU)1003, hInstance, NULL);

    // 相似度显示文本
    g_hwnd_similarity = CreateWindowW(L"STATIC", L"当前相似度：0.0000  |  阈值：0.7000",
        WS_VISIBLE | WS_CHILD | SS_CENTER,
        0, 95, 520, 40, hWnd, NULL, hInstance, NULL);
    // 右下角阈值小按钮
    HWND btn_threshold = CreateWindowW(L"BUTTON", L"阈值", WS_VISIBLE | WS_CHILD,
        460, 115, 50, 25, hWnd, (HMENU)1004, hInstance, NULL);

    // 设置控件字体
    SendMessage(g_hwnd_similarity, WM_SETFONT, (WPARAM)g_font, TRUE);
    if (btn_threshold && g_small_font) SendMessage(btn_threshold, WM_SETFONT, (WPARAM)g_small_font, TRUE);

    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);

    // 消息循环
    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return 0;
}