﻿#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <string>
#include <algorithm>
#include <locale>
#include <vector>
#include <regex>
#include <cwctype>

#include "../utils/utils.h"
// 模块：clean（实现）
// 说明：实现领域特定的文本清洗函数与通用清洗辅助，用于在编码前净化输入文本。
// 注意：本模块以宽字符串为主，输出日志使用 DebugLog。
#ifndef DebugLog
#define DebugLog(format, ...) printf(format, ##__VA_ARGS__)
#endif

// 基础字符清洗（窄字符串）
std::string clean_text(std::string s) {
    size_t l = s.find_first_not_of(" \t\n\r");
    size_t r = s.find_last_not_of(" \t\n\r");
    if (l > r) return "";
    return s.substr(l, r - l + 1);
}

// 辅助：去除宽字符串首尾空白
static void trim_wstring(std::wstring& ws) {
    ws.erase(ws.begin(), std::find_if(ws.begin(), ws.end(), [](wchar_t c) {
        return !iswspace(c);
        }));
    ws.erase(std::find_if(ws.rbegin(), ws.rend(), [](wchar_t c) {
        return !iswspace(c);
        }).base(), ws.end());
}

// 辅助：清洗回复行内无关内容（仅保留评论核心，删除分享/回复/时间/地区/数字/用户名前缀）
static std::wstring clean_reply_content(std::wstring line) {
    trim_wstring(line);
    if (line.empty()) return L"";

    // 1. 删除行首的"分享"|"回复"|"展开N条回复"等无关前缀
    std::wregex re_share_reply(L"^\\s*(分享|回复|展开\\d+条回复|展开)\\s*");
    line = std::regex_replace(line, re_share_reply, L"");

    // 2. 删除时间+地区后缀（如：3周前·新疆、2月前·山西）
    std::wregex re_reply_time(L"\\d+小时前·\\w+|\\d+天前·\\w+|\\d+周前·\\w+|\\d+月前·\\w+|\\d+天前·\\w+");
    line = std::regex_replace(line, re_reply_time, L"");

    // 3. 删除行尾纯数字（如评论点赞数18、12、44等）
    std::wregex re_tail_num(L"\\s*\\d+$");
    line = std::regex_replace(line, re_tail_num, L"");

    // 4. 删除独立的用户名行（仅保留评论内容，删除头像对后的纯用户名）
    std::wregex re_alone_username(L"^[^\\n:\\s！？。，、\\[\\]【】（）()@#￥%&*]+$");
    if (std::regex_match(line, re_alone_username) &&
        line.find(L"！") == std::wstring::npos &&
        line.find(L"？") == std::wstring::npos &&
        line.find(L"。") == std::wstring::npos &&
        line.find(L"，") == std::wstring::npos &&
        line.find(L"[") == std::wstring::npos &&
        line.find(L"]") == std::wstring::npos) {
        return L"";
    }

    // 再次清洗首尾空白
    trim_wstring(line);
    return line;
}

// 核心：业务级文本清洗（终极版 - 完全删除热门推荐+全部评论(xx)）
std::wstring clean_business_text(const std::wstring& raw_text) {
    DebugLog("[CLEAN] Raw text length: %d\n", (int)raw_text.size());

    // 步骤0：删除"202x © 抖音"到"全部评论(xx)"的所有内容（包括全部评论(xx)本身）
    std::wstring pre_cleaned_text = raw_text;
    // 正则匹配：202[0-9] © 抖音 开头，到 全部评论(\d+) 结尾的所有内容，直接替换为空
    std::wregex re_hot_recommend(L"202\\d © 抖音[\\s\\S]*?全部评论\\(\\d+\\)");
    pre_cleaned_text = std::regex_replace(pre_cleaned_text, re_hot_recommend, L"");

    // 步骤1：按换行分割预处理后的文本为行列表（保留原始行结构）
    std::vector<std::wstring> lines;
    std::wstring line_buf;
    for (wchar_t c : pre_cleaned_text) {
        if (c == L'\n' || c == L'\r') {
            if (!line_buf.empty()) {
                lines.push_back(line_buf);
                line_buf.clear();
            }
        }
        else {
            line_buf += c;
        }
    }
    if (!line_buf.empty()) {
        lines.push_back(line_buf);
    }
    DebugLog("[CLEAN] Lines after split: %d\n", (int)lines.size());

    // 步骤2：标记需要强制删除的行（平台垃圾信息+头像对+关注/下载+无效数字行）
    std::vector<bool> is_del(lines.size(), false);

    // 子步骤2.1：删除"xx头像\nxx"格式的连续两行（核心）
    for (size_t i = 0; i < lines.size() - 1; ++i) {
        if (is_del[i] || is_del[i + 1]) continue;

        std::wstring line1 = lines[i];
        std::wstring line2 = lines[i + 1];
        trim_wstring(line1);
        trim_wstring(line2);

        // 匹配任意"xx头像" + 下一行是"xx"（兼容特殊字符如括号、标点）
        size_t avatar_pos = line1.find(L"头像");
        if (avatar_pos != std::wstring::npos) {
            // 提取"头像"前的所有内容（兼容"抽不到张角不换头像"这类长文本）
            std::wstring prefix = line1.substr(0, avatar_pos);
            trim_wstring(prefix);
            // 下一行完全匹配前缀 或 前缀包含下一行（兼容特殊格式）
            if (!prefix.empty() && (line2 == prefix || prefix.find(line2) != std::wstring::npos)) {
                is_del[i] = true;
                is_del[i + 1] = true;
                DebugLog("[CLEAN] Delete avatar pair lines: %d & %d\n", (int)i, (int)i + 1);
                i++; // 跳过下一行，避免重复处理
            }
        }
    }

    // 子步骤2.2：删除单行仅含"关注"/"下载"/纯数字/平台垃圾关键词的行
    const std::vector<std::wstring> single_del_keywords = {
        L"关注", L"下载", L"粉丝", L"获赞", L"抖音号：", L"保存登录信息", L"批量管理",
        L"搜索你收藏的作品", L"暂时没有更多了", L"广告投放", L"用户服务协议", L"隐私政策",
        L"账号找回", L"联系我们", L"加入我们", L"营业执照", L"友情链接", L"站点地图",
        L"抖音电商", L"网络谣言曝光台", L"网上有害信息举报", L"违法和不良信息举报",
        L"算法推荐专项举报", L"网络内容从业人员违法违规行为举报", L"体育饭圈专项举报",
        L"加载中", L"留下你的精彩评论吧", L"看相关", L"共\\d+人推荐", L"开启读屏标签读屏标签已关闭",
        L"下载抖音精选", L"京ICP备", L"京公网安备", L"广播电视节目制作经营许可证",
        L"京B2-", L"网络文化许可证", L"互联网宗教信息服务许可证", L"药品医疗器械网络信息服务备案",
        L"互联网新闻信息服务许可证"
    };

    for (size_t i = 0; i < lines.size(); ++i) {
        if (is_del[i]) continue;

        std::wstring curr_line = lines[i];
        trim_wstring(curr_line);

        // 1. 删除纯数字行（如2、0、2.1万、490等）
        std::wregex re_pure_num(L"^\\s*\\d+(\\.\\d+)?万?\\s*$");
        if (std::regex_match(curr_line, re_pure_num)) {
            is_del[i] = true;
            continue;
        }

        // 2. 删除含平台垃圾关键词的单行
        for (const auto& kw : single_del_keywords) {
            if (curr_line.find(kw) != std::wstring::npos || curr_line == kw) {
                is_del[i] = true;
                break;
            }
        }

        // 3. 删除独立的@用户名行（如@高数AI学）
        std::wregex re_alone_at(L"^\\s*@[^\\n:\\s]+\\s*$");
        if (std::regex_match(curr_line, re_alone_at)) {
            is_del[i] = true;
        }

        // 4. 删除纯日期行（如· 1月11日）
        std::wregex re_pure_date(L"^\\s*·\\s*\\d+月\\d+日\\s*$");
        if (std::regex_match(curr_line, re_pure_date)) {
            is_del[i] = true;
        }

        // 5. 删除"202x © 抖音"单行（防止漏删）
        std::wregex re_douyin_copyright(L"^\\s*202\\d © 抖音\\s*$");
        if (std::regex_match(curr_line, re_douyin_copyright)) {
            is_del[i] = true;
        }

        // 6. 兜底删除漏网的"全部评论(xx)"行
        std::wregex re_all_comments(L"^\\s*全部评论\\(\\d+\\)\\s*$");
        if (std::regex_match(curr_line, re_all_comments)) {
            is_del[i] = true;
        }
    }

    // 步骤3：逐行清洗，仅保留核心内容
    std::vector<std::wstring> valid_lines;
    for (size_t i = 0; i < lines.size(); ++i) {
        // 跳过已标记删除的行
        if (is_del[i]) continue;

        std::wstring curr_line = lines[i];
        trim_wstring(curr_line);

        // 跳过空行
        if (curr_line.empty()) continue;

        // 核心清洗：删除回复区无关内容，仅保留评论核心
        std::wstring cleaned_line = clean_reply_content(curr_line);
        if (cleaned_line.empty()) continue;

        // 保留有效行（去重空行）
        valid_lines.push_back(cleaned_line);
    }

    // 步骤4：合并有效行，生成最终清洗结果（匹配手动换行格式）
    std::wstring cleaned_text;
    for (size_t i = 0; i < valid_lines.size(); ++i) {
        cleaned_text += valid_lines[i];
        if (i != valid_lines.size() - 1) {
            cleaned_text += L"\n";
        }
    }

    // 输出最终统计
    DebugLog("[CLEAN] Final valid lines: %d\n", (int)valid_lines.size());
    DebugLog("[CLEAN] Final text length: %d -> %d\n",
        (int)raw_text.size(), (int)cleaned_text.size());

    return cleaned_text;
}