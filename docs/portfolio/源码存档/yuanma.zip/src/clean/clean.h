﻿#pragma once
#include <string>
#include <wchar.h>

// 模块：clean
// 说明：提供文本规范化与领域特定的清洗工具，供模型编码前使用。
// 备注：包含窄字符串与宽字符串版本的清洗函数。

// 功能：对窄字符串进行首尾空白清理与基本修整。
// 输入：s - 待清洗的窄字符串
// 输出：返回清洗后的窄字符串（可能为空）
std::string clean_text(std::string s);

// 功能：业务级文本清洗，删除平台噪声（如"全部评论"、广告、时间戳等），保留评论核心内容。
// 输入：raw_text - 原始宽字符串（可能包含多行）
// 输出：返回清洗后的宽字符串（按原始行分隔合并），若无有效内容返回空字符串
std::wstring clean_business_text(const std::wstring& raw_text);
