﻿#pragma once
#include <vector>
#include <string>

// 模块：模型处理 (model)
// 功能：加载 ONNX 模型与 SentencePiece 分词器，将文本编码为特征向量
// 对外接口：加载/卸载模型、文本编码、设置/获取模板向量

// 加载 ONNX 模型并初始化分词器，成功返回 true
bool load_model(const wchar_t* path);

// 卸载模型并释放资源
void unload_model();

// 将宽字符串文本编码为浮点型特征向量，成功返回 true
bool model_encode(const std::wstring& text, std::vector<float>& embedding);

// 辅助函数：设置模板文本并预计算其特征向量
void set_template_text(const std::wstring& text);

// 辅助函数：获取内部模板特征向量（引用返回）
std::vector<float>& get_template_embedding();
