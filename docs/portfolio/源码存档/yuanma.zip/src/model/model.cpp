﻿#define _CRT_SECURE_NO_WARNINGS  // 顶格，无空格
// 1. 关闭所有C++17废弃警告（只定义一次，避免C4005）
#ifdef _SILENCE_ALL_CXX17_DEPRECATION_WARNINGS
#undef _SILENCE_ALL_CXX17_DEPRECATION_WARNINGS
#endif
#define _SILENCE_ALL_CXX17_DEPRECATION_WARNINGS  // 顶格

// ========== 适配0.2.1：引入SentencePiece头文件 + 链接库 ==========
#include "../include/sentencepiece_processor.h"
#pragma comment(lib, "sentencepiece.lib")

// 2. Windows核心头文件（兼容所有Windows版本）
#include <Windows.h>
// 3. 链接Shlwapi库（路径处理需要）
#pragma comment(lib, "Shlwapi.lib")
// 4. 关闭无关警告
#pragma warning(disable: 28251)
#pragma warning(disable: 4566)
#pragma warning(disable: 4005)

#include "model.h"
#include "../utils/utils.h"  // 新增：引入DebugLog的定义
#include <onnxruntime_c_api.h>
#include <vector>
#include <string>
#include <algorithm>
// 必须包含string头文件，否则std::to_string会报错
#include <string>
// 引入清洗模块的头文件
#include "../clean/clean.h"
// 线程/互斥
#include <mutex>

// 模块：model（实现）
// 说明：加载 SentencePiece 分词器与 ONNX Runtime 会话，提供文本到向量的编码接口。
// 备注：文件包含全局会话对象与编码辅助函数，注意线程安全与资源释放时序。

// ========== 适配0.2.1：全局变量调整 ==========
sentencepiece::SentencePieceProcessor g_sp_processor;
const std::wstring g_sp_model_path = L"C:\\Users\\Administrator\\Desktop\\VideoDemo\\x64\\Release\\models\\sentencepiece.bpe.model";
// 新增标记：判断SentencePiece是否加载成功（替代IsLoaded）
bool g_sp_loaded = false;

// 互斥保护：序列化对全局ORT/Session/SpProcessor的访问
static std::mutex g_model_mutex;

// 原有全局变量
const OrtApi* g_ort = nullptr;
OrtEnv* g_env = nullptr;
OrtSession* g_session = nullptr;
static std::vector<float> s_template_embedding;

// ============================
// 宽字符串转UTF8（纯Windows API，无废弃警告）
// ============================
std::string wstring_to_utf8(const std::wstring& wstr) {
    if (wstr.empty()) return "";
    // Use -1 to include terminating null in the required length, then remove it from std::string
    int len = WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), -1, NULL, 0, NULL, NULL);
    if (len <= 0) return "";
    std::string utf8_str(len - 1, 0); // exclude terminating null
    WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), -1, &utf8_str[0], len, NULL, NULL);
    return utf8_str;
}

// ========== 适配0.2.1：加载SentencePiece模型（修正Load返回值） ==========
bool load_sentencepiece_model() {
    std::string sp_model_utf8 = wstring_to_utf8(g_sp_model_path);

    // 0.2.1版本：Load返回Status对象，用.ok()判断是否成功
    sentencepiece::util::Status status = g_sp_processor.Load(sp_model_utf8);
    if (!status.ok()) {
        DebugLog("[ERROR] 加载SentencePiece模型失败：%s，错误：%s",
            sp_model_utf8.c_str(), status.ToString().c_str());
        g_sp_loaded = false;
        return false;
    }

    g_sp_loaded = true;
    DebugLog("[INFO] SentencePiece模型加载成功：%ls", g_sp_model_path.c_str());
    return true;
}

// ========== 适配0.2.1：SentencePiece分词（修正PieceToId API + 增强日志） ==========
// 功能：将宽字符串文本进行 SentencePiece 分词，返回 token id 列表与 attention mask。
// 输入：text - 宽字符串文本；max_len - 最大 token 长度
// 输出：ids - 填充后的 input_ids（含 CLS/SEP/PAD），mask - attention mask (1=有效,0=PAD)
void tokenize(const std::wstring& text, std::vector<int64_t>& ids, std::vector<int64_t>& mask, int max_len) {
    ids.clear();
    mask.clear();

    std::string text_utf8 = wstring_to_utf8(text);
    // Log the token input text as wide string to avoid any narrow-encoding display issues
    {
        std::string snippet_utf8 = text_utf8.substr(0, 100);
        int wlen = MultiByteToWideChar(CP_UTF8, 0, snippet_utf8.c_str(), -1, NULL, 0);
        if (wlen > 0) {
            std::wstring snippet(wlen - 1, L'\0');
            MultiByteToWideChar(CP_UTF8, 0, snippet_utf8.c_str(), -1, &snippet[0], wlen);
            DebugLogW(L"[TOKEN] 分词输入文本（UTF8）：%ls", snippet.c_str());
        }
        else {
            DebugLog("[TOKEN] 分词输入文本（UTF8）：%s", snippet_utf8.c_str());
        }
    }
    // 写入 text_utf8 的前64字节为十六进制，便于离线分析
    {
        int dump_len = (int)text_utf8.size() > 64 ? 64 : (int)text_utf8.size();
        FILE* fh = nullptr;
        if (fopen_s(&fh, "token_input_hex.txt", "ab") == 0 && fh) {
            fprintf(fh, "---- SAMPLE ----\n");
            for (int i = 0; i < dump_len; ++i) fprintf(fh, "%02X ", (unsigned char)text_utf8[i]);
            fprintf(fh, "\n");
            fclose(fh);
        }
    }

    std::vector<int> temp_ids;
    g_sp_processor.Encode(text_utf8, &temp_ids);
    DebugLog("[TOKEN] 原始分词结果长度：%d", (int)temp_ids.size());
    // 诊断：打印原始 temp_ids 前50个
    {
        int show = (int)temp_ids.size() > 50 ? 50 : (int)temp_ids.size();
        std::string tmp;
        for (int i = 0; i < show; ++i) tmp += std::to_string(temp_ids[i]) + " ";
        DebugLog("[TOKEN] temp_ids 前%d个: %s", show, tmp.c_str());
    }

    const int64_t ID_CLS = g_sp_processor.PieceToId("<s>");
    const int64_t ID_SEP = g_sp_processor.PieceToId("</s>");
    const int64_t ID_PAD = g_sp_processor.PieceToId("<pad>");
    DebugLog("[TOKEN] 特殊token：CLS=%lld, SEP=%lld, PAD=%lld", ID_CLS, ID_SEP, ID_PAD);

    // ========== 关键修改：跳过前N个固定token ==========
    int skip_tokens = 0; // 调试时不要跳过token；上线可调回200以跳过固定前缀
    // 打印原始前20个token id，便于调试
    {
        std::string tmpid_str;
        int tmp_cnt = (int)temp_ids.size() > 20 ? 20 : (int)temp_ids.size();
        for (int i = 0; i < tmp_cnt; i++) tmpid_str += std::to_string(temp_ids[i]) + " ";
        DebugLog("[TOKEN] 原始分词前%d个id: %s", tmp_cnt, tmpid_str.c_str());
    }

    std::vector<int> filtered_temp_ids;
    if (skip_tokens > 0 && temp_ids.size() > (size_t)skip_tokens) {
        filtered_temp_ids.assign(temp_ids.begin() + skip_tokens, temp_ids.end());
        DebugLog("[TOKEN] 跳过前%d个固定token，剩余token数：%d", skip_tokens, (int)filtered_temp_ids.size());
    }
    else {
        filtered_temp_ids = temp_ids; // 不足则保留全部或者不跳过
    }
    // 诊断：打印过滤后前50个token id，便于比对不同输入
    {
        int show = (int)filtered_temp_ids.size() > 50 ? 50 : (int)filtered_temp_ids.size();
        std::string tmp;
        for (int i = 0; i < show; ++i) tmp += std::to_string(filtered_temp_ids[i]) + " ";
        DebugLog("[TOKEN] filtered_temp_ids 前%d个: %s", show, tmp.c_str());
    }
    // ==============================================

    // 开头加CLS
    ids.push_back(ID_CLS);
    // 添加过滤后的分词结果（留位置给SEP）
    for (int id : filtered_temp_ids) { // 用过滤后的token列表
        if (ids.size() >= max_len - 1) break;
        ids.push_back(static_cast<int64_t>(id));
    }
    // 结尾加SEP
    if (ids.size() < max_len) {
        ids.push_back(ID_SEP);
    }
    // 补PAD到max_len
    while (ids.size() < max_len) {
        ids.push_back(ID_PAD);
    }

    // 生成attention_mask（1=有效token，0=PAD）
    mask.assign(max_len, 0);
    for (size_t i = 0; i < ids.size() && i < max_len; i++) {
        mask[i] = (ids[i] != ID_PAD) ? 1 : 0;
    }

    // 打印前20个input_ids
    std::string id_str;
    int id_count = (int)ids.size() > 20 ? 20 : (int)ids.size();
    for (int i = 0; i < id_count; i++) {
        id_str += std::to_string(ids[i]) + " ";
    }
    DebugLog("[TOKEN] input_ids前20个: %s", id_str.c_str());

    // 打印mask前20个
    std::string mask_str;
    int mask_count = (int)mask.size() > 20 ? 20 : (int)mask.size();
    for (int i = 0; i < mask_count; i++) {
        mask_str += std::to_string(mask[i]) + " ";
    }
    DebugLog("[TOKEN] mask前20个: %s", mask_str.c_str());
}

// ============================
// 模型编码（适配0.2.1 + 增强错误日志）
// 功能：将宽字符串文本编码为浮点向量（embedding）
// 输入：text - 待编码文本
// 输出：embedding - 输出向量（CLS token）
// 返回：成功返回 true 并填充 embedding，否则返回 false
// 备注：函数线程安全（内部使用互斥锁），并对 ONNX Runtime 调用进行错误日志记录
// ============================
bool model_encode(const std::wstring& text, std::vector<float>& embedding)
{
    std::lock_guard<std::mutex> lk(g_model_mutex);
    embedding.clear();
    OrtMemoryInfo* mi = nullptr;
    OrtStatus* status = nullptr;
    OrtValue* in_ids = nullptr;
    OrtValue* in_tt = nullptr;
    OrtValue* in_mask = nullptr;
    OrtValue* out = nullptr;
    float* data = nullptr;
    const char* inputs[] = { "input_ids", "token_type_ids", "attention_mask" };
    const char* outputs[] = { "last_hidden_state" };
    OrtValue* tensors[] = { nullptr, nullptr, nullptr };

    // 适配0.2.1：用自定义标记g_sp_loaded替代IsLoaded()
    if (!g_session || !g_sp_loaded || text.empty()) {
        DebugLog("[ERROR] 模型编码失败：g_session=%p, g_sp_loaded=%d, text_len=%d",
            g_session, g_sp_loaded, (int)text.size());
        return false;
    }

    const int max_len = 128;
    std::vector<int64_t> input_ids, token_type_ids, attention_mask;
    tokenize(text, input_ids, attention_mask, max_len);
    token_type_ids.assign(max_len, 0);

    // 创建内存信息
    status = g_ort->CreateCpuMemoryInfo(OrtDeviceAllocator, OrtMemTypeDefault, &mi);
    if (status != nullptr) {
        DebugLog("[ERROR] 创建内存信息失败：%s", g_ort->GetErrorMessage(status));
        g_ort->ReleaseStatus(status);
        return false;
    }

    // 创建input_ids张量
    const int64_t shape[] = { 1, max_len };
    status = g_ort->CreateTensorWithDataAsOrtValue(mi, input_ids.data(), max_len * sizeof(int64_t),
        shape, 2, ONNX_TENSOR_ELEMENT_DATA_TYPE_INT64, &in_ids);
    if (status != nullptr) {
        DebugLog("[ERROR] 创建input_ids张量失败：%s", g_ort->GetErrorMessage(status));
        g_ort->ReleaseStatus(status);
        g_ort->ReleaseMemoryInfo(mi);
        return false;
    }

    // 创建token_type_ids张量
    status = g_ort->CreateTensorWithDataAsOrtValue(mi, token_type_ids.data(), max_len * sizeof(int64_t),
        shape, 2, ONNX_TENSOR_ELEMENT_DATA_TYPE_INT64, &in_tt);
    if (status != nullptr) {
        DebugLog("[ERROR] 创建token_type_ids张量失败：%s", g_ort->GetErrorMessage(status));
        g_ort->ReleaseStatus(status);
        g_ort->ReleaseValue(in_ids);
        g_ort->ReleaseMemoryInfo(mi);
        return false;
    }

    // 创建attention_mask张量
    status = g_ort->CreateTensorWithDataAsOrtValue(mi, attention_mask.data(), max_len * sizeof(int64_t),
        shape, 2, ONNX_TENSOR_ELEMENT_DATA_TYPE_INT64, &in_mask);
    if (status != nullptr) {
        DebugLog("[ERROR] 创建attention_mask张量失败：%s", g_ort->GetErrorMessage(status));
        g_ort->ReleaseStatus(status);
        g_ort->ReleaseValue(in_ids);
        g_ort->ReleaseValue(in_tt);
        g_ort->ReleaseMemoryInfo(mi);
        return false;
    }

    tensors[0] = in_ids;
    tensors[1] = in_tt;
    tensors[2] = in_mask;

    // 模型推理
    status = g_ort->Run(g_session, nullptr, inputs, (const OrtValue**)tensors, 3, outputs, 1, &out);
    if (status != nullptr) {
        DebugLog("[ERROR] 模型推理失败：%s", g_ort->GetErrorMessage(status));
        g_ort->ReleaseStatus(status);
        g_ort->ReleaseValue(in_ids);
        g_ort->ReleaseValue(in_tt);
        g_ort->ReleaseValue(in_mask);
        g_ort->ReleaseMemoryInfo(mi);
        return false;
    }

    // 打印运行成功信息
    DebugLog("[MODEL] Run执行成功，准备获取输出shape和数据");

    // 提取输出数据之前，校验输出tensor的类型和shape
    OrtTensorTypeAndShapeInfo* shape_info = nullptr;
    status = g_ort->GetTensorTypeAndShape(out, &shape_info);
    if (status != nullptr || !shape_info) {
        DebugLog("[ERROR] 获取输出tensor shape失败：%s", status ? g_ort->GetErrorMessage(status) : "null shape_info");
        if (status) g_ort->ReleaseStatus(status);
        g_ort->ReleaseValue(in_ids);
        g_ort->ReleaseValue(in_tt);
        g_ort->ReleaseValue(in_mask);
        g_ort->ReleaseValue(out);
        g_ort->ReleaseMemoryInfo(mi);
        return false;
    }

    size_t dim_count = 0;
    g_ort->GetDimensionsCount(shape_info, &dim_count);
    std::vector<int64_t> dims(dim_count);
    g_ort->GetDimensions(shape_info, dims.data(), (int)dim_count);
    // 假设输出为 [1, seq_len, hidden_size] 或 [seq_len, hidden_size]
    int64_t hidden_size = 0;
    if (dim_count == 3) {
        hidden_size = dims[2];
    }
    else if (dim_count == 2) {
        hidden_size = dims[1];
    }
    else {
        DebugLog("[ERROR] 输出tensor维度不符合预期，dim_count=%d", (int)dim_count);
    }

    g_ort->ReleaseTensorTypeAndShapeInfo(shape_info);

    status = g_ort->GetTensorMutableData(out, (void**)&data);
    if (status != nullptr) {
        DebugLog("[ERROR] 提取输出数据失败：%s", g_ort->GetErrorMessage(status));
        g_ort->ReleaseStatus(status);
        g_ort->ReleaseValue(in_ids);
        g_ort->ReleaseValue(in_tt);
        g_ort->ReleaseValue(in_mask);
        g_ort->ReleaseValue(out);
        g_ort->ReleaseMemoryInfo(mi);
        return false;
    }

    // 取CLS token（第一个位置）的hidden_size维向量
    if (hidden_size <= 0) hidden_size = 384; // fallback
    embedding.assign(data, data + hidden_size);

    // 打印embedding前16个元素和范数，便于调试
    float sum = 0.0f;
    std::string emb_str;
    int print_cnt = hidden_size > 16 ? 16 : hidden_size;
    for (int i = 0; i < hidden_size; i++) {
        sum += embedding[i] * embedding[i];
        if (i < print_cnt) emb_str += std::to_string(embedding[i]) + " ";
    }
    DebugLog("[MODEL] embedding长度=%d, 前%d个值=%s, 范数=%.6f", (int)embedding.size(), print_cnt, emb_str.c_str(), sum);

    // 诊断：打印输出tensor的dims，以确认取CLS位置是否正确
    {
        OrtTensorTypeAndShapeInfo* out_shape_info = nullptr;
        if (g_ort->GetTensorTypeAndShape(out, &out_shape_info) == nullptr && out_shape_info) {
            size_t dc = 0; g_ort->GetDimensionsCount(out_shape_info, &dc);
            std::vector<int64_t> od(dc);
            g_ort->GetDimensions(out_shape_info, od.data(), (int)dc);
            std::string s;
            for (size_t i = 0; i < dc; ++i) s += std::to_string(od[i]) + " ";
            DebugLog("[MODEL] 输出tensor dims (%d): %s", (int)dc, s.c_str());
            g_ort->ReleaseTensorTypeAndShapeInfo(out_shape_info);
        }
    }

    // 检查向量是否全0
    sum = 0.0f; // reuse existing variable instead of redeclaring
    for (float f : embedding) sum += f * f;
    if (sum < 1e-6) {
        DebugLog("[ERROR] 编码结果为全0向量！");
        embedding.clear();
        return false;
    }

    DebugLog("[MODEL] 编码完成，向量长度：%d，向量平方和：%.6f", (int)embedding.size(), sum);

    // 释放资源
    g_ort->ReleaseValue(in_ids);
    g_ort->ReleaseValue(in_tt);
    g_ort->ReleaseValue(in_mask);
    g_ort->ReleaseValue(out);
    g_ort->ReleaseMemoryInfo(mi);
    if (status) g_ort->ReleaseStatus(status);

    return !embedding.empty();
}

// ============================
// 加载模型（原有逻辑不变，优先加载分词模型）
// ============================
bool load_model(const wchar_t* path)
{
    std::lock_guard<std::mutex> lk(g_model_mutex);

    if (g_session) return true;

    if (!load_sentencepiece_model()) {
        return false;
    }

    g_ort = OrtGetApiBase()->GetApi(ORT_API_VERSION);
    if (!g_ort) {
        DebugLog("[ERROR] 获取ONNX Runtime API失败");
        return false;
    }

    OrtStatus* status = g_ort->CreateEnv(ORT_LOGGING_LEVEL_WARNING, "AI筛选器", &g_env);
    if (status != nullptr) {
        DebugLog("[ERROR] 创建Env失败：%s", g_ort->GetErrorMessage(status));
        g_ort->ReleaseStatus(status);
        return false;
    }

    OrtSessionOptions* opt = nullptr;
    status = g_ort->CreateSessionOptions(&opt);
    if (status != nullptr) {
        DebugLog("[ERROR] 创建SessionOptions失败");
        g_ort->ReleaseStatus(status);
        return false;
    }

    status = g_ort->CreateSession(g_env, path, opt, &g_session);
    g_ort->ReleaseSessionOptions(opt);
    if (status != nullptr) {
        DebugLog("[ERROR] 加载模型失败：%s", g_ort->GetErrorMessage(status));
        g_ort->ReleaseStatus(status);
        return false;
    }

    DebugLog("[INFO] 使用SentencePiece 0.2.1标准分词（适配paraphrase-multilingual-MiniLM）");
    DebugLog("[MODEL] ONNX模型加载成功：%ls", path);

    return true;
}

// ============================
// 卸载模型（适配0.2.1：移除Reset，重置标记）
// ============================
void unload_model()
{
    // 适配0.2.1：0.2.1没有Reset()，重置标记即可
    g_sp_loaded = false;

    // 原有逻辑：在释放前确保 g_ort 有效
    if (g_ort) {
        if (g_session) {
            g_ort->ReleaseSession(g_session);
            g_session = nullptr;
        }
        if (g_env) {
            g_ort->ReleaseEnv(g_env);
            g_env = nullptr;
        }
        g_ort = nullptr;
    }
    s_template_embedding.clear();
    DebugLog("[MODEL] 模型及SentencePiece分词器已卸载");
}

// ============================
// 设置模板文本并编码（原有逻辑不变）
// ============================
void set_template_text(const std::wstring& text)
{
    model_encode(text, s_template_embedding);
    DebugLog("[INFO] 模板文本已编码，向量长度：%d", (int)s_template_embedding.size());
}

// ============================
// 获取模板向量（原有逻辑不变）
// ============================
std::vector<float>& get_template_embedding()
{
    return s_template_embedding;
}
