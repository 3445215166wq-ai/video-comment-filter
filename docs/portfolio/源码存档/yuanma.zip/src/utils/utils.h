#pragma once
#include <Windows.h>
#include <string>
#include <vector>

// 模块：utils
// 说明：输入模拟（鼠标/键盘）、剪贴板读取、日志、文件与路径等实用工具函数集合。
// 备注：日志函数默认输出宽字符串到调试器，并以 UTF-8 写入调试文件。

void DebugLog(const char* fmt, ...);
// 输出宽字符串日志到调试器及日志文件（支持格式化）
void DebugLogW(const wchar_t* fmt, ...);

void CtrlA_Only();
void CtrlC_Only();
// 模拟键鼠操作
void Press_C_Only();           // 模拟按下并松开 C 键
void RightClickPage();         // 模拟鼠标右键单击
void LeftClickMouse();         // 模拟鼠标左键单击

// 鼠标定位（根据窗口句柄移动鼠标）
void MoveMouseToWindowCenter(HWND hWnd);       // 将鼠标移动到窗口中心
void MoveMouseToWindowRight(HWND hWnd);        // 将鼠标移动到窗口右侧区域
void MoveMouseToWindowRightTopThird(HWND hWnd); // 移动到窗口右侧偏上 1/3 靠近边缘位置

// 剪贴板操作
bool ReadTextFromClipboard(std::wstring& outText); // 从剪贴板读取文本（支持多种格式）
void ResetClipboard();                             // 清空剪贴板内容

// 辅助控制
void MouseScrollDown();               // 模拟鼠标滚轮向下滚动
bool IsKeyPress_P();                  // 检测 P 键是否按下
void SendEscapeKey();                 // 模拟按下并松开 ESC 键

// 数学计算
float calc_similarity(const std::vector<float>& vec1, const std::vector<float>& vec2); // 计算两个向量的余弦相似度

// 文件与路径
std::wstring GetAppDir();             // 获取当前程序所在目录
std::wstring ReadTemplateFile();      // 读取 data/template.txt 模板文件内容
