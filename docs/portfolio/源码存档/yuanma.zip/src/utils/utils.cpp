﻿#define _CRT_SECURE_NO_WARNINGS
#include "utils.h"
#include <assert.h>

/********************************************************************
 * 模块：工具函数集合 (utils.cpp)
 * 功能：提供日志输出、键鼠模拟、剪贴板操作、文件路径、向量相似度等通用工具
 * 说明：日志支持宽字符调试输出 + UTF-8文件写入，避免中文乱码
 ********************************************************************/

#include <stdio.h>
#include <stdarg.h>
#include <cmath>
#include <fstream>
#include <Shlwapi.h>
#include <shellapi.h>

#pragma comment(lib, "Shlwapi.lib")   // 路径处理相关库
#pragma comment(lib, "Shell32.lib")   // 剪贴板文件拖拽相关库

 /********************************************************************
  * 函数：DebugLog
  * 功能：UTF-8/ANSI 字符串日志输出（输出到调试器 + 写入日志文件）
  * 参数：fmt - 格式化字符串；... - 可变参数
  * 备注：自动检测UTF-8，文件写入带BOM，确保中文正常显示
  ********************************************************************/
void DebugLog(const char* fmt, ...)
{
    // 定义日志缓冲区
    char buf[2048] = { 0 };
    va_list ap;
    va_start(ap, fmt);
    vsprintf_s(buf, _countof(buf), fmt, ap); // 格式化字符串到缓冲区
    va_end(ap);

    // UTF-8 编码合法性检测（匿名函数）
    auto is_valid_utf8 = [](const char* data, size_t len) -> bool {
        const unsigned char* bytes = (const unsigned char*)data;
        size_t i = 0;
        while (i < len) {
            unsigned char c = bytes[i];
            if (c <= 0x7F) { // ASCII字符，单字节
                i++;
                continue;
            }
            else if ((c >> 5) == 0x6) { // 双字节UTF-8
                if (i + 1 >= len) return false;
                unsigned char c1 = bytes[i + 1];
                if ((c1 >> 6) != 0x2) return false;
                i += 2;
            }
            else if ((c >> 4) == 0xE) { // 三字节UTF-8
                if (i + 2 >= len) return false;
                unsigned char c1 = bytes[i + 1], c2 = bytes[i + 2];
                if ((c1 >> 6) != 0x2 || (c2 >> 6) != 0x2) return false;
                i += 3;
            }
            else if ((c >> 3) == 0x1E) { // 四字节UTF-8
                if (i + 3 >= len) return false;
                unsigned char c1 = bytes[i + 1], c2 = bytes[i + 2], c3 = bytes[i + 3];
                if ((c1 >> 6) != 0x2 || (c2 >> 6) != 0x2 || (c3 >> 6) != 0x2) return false;
                i += 4;
            }
            else {
                return false; // 无效编码
            }
        }
        return true;
        };

    size_t buflen = strlen(buf);
    bool buf_is_utf8 = buflen > 0 && is_valid_utf8(buf, buflen);

    // 转换为宽字符并输出到调试器（优先UTF-8，失败则用系统默认编码）
    int wlen = MultiByteToWideChar(buf_is_utf8 ? CP_UTF8 : CP_ACP, 0, buf, -1, NULL, 0);
    if (wlen > 0) {
        std::wstring wbuf(wlen - 1, L'\0');
        MultiByteToWideChar(buf_is_utf8 ? CP_UTF8 : CP_ACP, 0, buf, -1, &wbuf[0], wlen);
        OutputDebugStringW(wbuf.c_str()); // 输出到VS调试窗口
    }
    else {
        OutputDebugStringA(buf); // 兜底：直接输出ANSI
    }

    // 以追加模式打开日志文件，写入UTF-8内容
    FILE* f = nullptr;
    errno_t err = fopen_s(&f, "videodemo_debug.txt", "ab");
    if (err == 0 && f) {
        long pos = ftell(f);
        if (pos == 0) { // 文件为空时写入UTF-8 BOM头
            const unsigned char bom[] = { 0xEF, 0xBB, 0xBF };
            fwrite(bom, 1, sizeof(bom), f);
        }

        if (buf_is_utf8) {
            fwrite(buf, 1, buflen, f); // 直接写入UTF-8
        }
        else {
            // ANSI转宽字符，再转UTF-8写入
            int wlen2 = MultiByteToWideChar(CP_ACP, 0, buf, (int)buflen, NULL, 0);
            if (wlen2 > 0) {
                std::wstring tmp(wlen2, L'\0');
                MultiByteToWideChar(CP_ACP, 0, buf, (int)buflen, &tmp[0], wlen2);
                int outlen = WideCharToMultiByte(CP_UTF8, 0, tmp.c_str(), (int)tmp.size(), NULL, 0, NULL, NULL);
                if (outlen > 0) {
                    std::string out(outlen, '\0');
                    WideCharToMultiByte(CP_UTF8, 0, tmp.c_str(), (int)tmp.size(), &out[0], outlen, NULL, NULL);
                    fwrite(out.data(), 1, out.size(), f);
                }
            }
        }
        fwrite("\n", 1, 1, f); // 换行
        fclose(f);
    }
}

/********************************************************************
 * 函数：DebugLogW
 * 功能：宽字符版本日志输出（直接接收wchar_t*）
 * 参数：fmt - 宽字符格式化字符串
 ********************************************************************/
void DebugLogW(const wchar_t* fmt, ...)
{
    wchar_t wbuf[2048] = { 0 };
    va_list ap;
    va_start(ap, fmt);
    vswprintf_s(wbuf, _countof(wbuf), fmt, ap);
    va_end(ap);

    // 输出到调试器
    OutputDebugStringW(wbuf);

    // 转换为UTF-8并写入日志文件
    int utf8_len = WideCharToMultiByte(CP_UTF8, 0, wbuf, -1, NULL, 0, NULL, NULL);
    if (utf8_len > 0) {
        std::string out(utf8_len - 1, '\0');
        WideCharToMultiByte(CP_UTF8, 0, wbuf, -1, &out[0], utf8_len, NULL, NULL);

        FILE* f = nullptr;
        errno_t err = fopen_s(&f, "videodemo_debug.txt", "ab");
        if (err == 0 && f) {
            long pos = ftell(f);
            if (pos == 0) { // 空文件写入BOM
                const unsigned char bom[] = { 0xEF, 0xBB, 0xBF };
                fwrite(bom, 1, sizeof(bom), f);
            }
            fwrite(out.c_str(), 1, out.size(), f);
            fwrite("\n", 1, 1, f);
            fclose(f);
        }
    }
}

/********************************************************************
 * 函数：CtrlA_Only
 * 功能：模拟键盘 Ctrl+A 全选操作
 ********************************************************************/
void CtrlA_Only()
{
    INPUT input[2] = { 0 };
    // 按下 Ctrl + A
    input[0].type = INPUT_KEYBOARD;
    input[0].ki.wVk = VK_CONTROL;
    input[1].type = INPUT_KEYBOARD;
    input[1].ki.wVk = 'A';
    SendInput(2, input, sizeof(INPUT));
    Sleep(100);

    // 松开 Ctrl + A
    input[0].ki.dwFlags = KEYEVENTF_KEYUP;
    input[1].ki.dwFlags = KEYEVENTF_KEYUP;
    SendInput(2, input, sizeof(INPUT));
    Sleep(200);
}

/********************************************************************
 * 函数：CtrlC_Only
 * 功能：模拟键盘 Ctrl+C 复制操作
 ********************************************************************/
void CtrlC_Only()
{
    INPUT in[2] = { 0 };
    // 按下 Ctrl + C
    in[0].type = INPUT_KEYBOARD; in[0].ki.wVk = VK_CONTROL;
    in[1].type = INPUT_KEYBOARD; in[1].ki.wVk = 'C';
    SendInput(2, in, sizeof(INPUT));
    Sleep(100);

    // 松开 Ctrl + C
    in[0].ki.dwFlags = KEYEVENTF_KEYUP;
    in[1].ki.dwFlags = KEYEVENTF_KEYUP;
    SendInput(2, in, sizeof(INPUT));
    Sleep(200);
}

/********************************************************************
 * 函数：Press_C_Only
 * 功能：仅模拟按下并松开 C 键（单键复制）
 ********************************************************************/
void Press_C_Only()
{
    INPUT input = { 0 };

    // 按下 C
    input.type = INPUT_KEYBOARD;
    input.ki.wVk = 'C';
    SendInput(1, &input, sizeof(INPUT));
    Sleep(150);

    // 松开 C
    input.ki.dwFlags = KEYEVENTF_KEYUP;
    SendInput(1, &input, sizeof(INPUT));
    Sleep(200);
}

/********************************************************************
 * 函数：RightClickPage
 * 功能：模拟鼠标右键单击
 ********************************************************************/
void RightClickPage()
{
    mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, 0);
    Sleep(100);
    mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0);
    Sleep(300);
}

/********************************************************************
 * 函数：LeftClickMouse
 * 功能：模拟鼠标左键单击
 ********************************************************************/
void LeftClickMouse()
{
    mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
    Sleep(50);
    mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
    Sleep(500);
}

/********************************************************************
 * 函数：MoveMouseToWindowCenter
 * 功能：将鼠标移动到指定窗口的中心位置
 * 参数：hWnd - 目标窗口句柄
 ********************************************************************/
void MoveMouseToWindowCenter(HWND hWnd)
{
    RECT r;
    GetWindowRect(hWnd, &r); // 获取窗口屏幕坐标
    int x = (r.left + r.right) / 2;
    int y = (r.top + r.bottom) / 2;
    SetCursorPos(x, y);
    Sleep(200);
}

/********************************************************************
 * 函数：MoveMouseToWindowRight
 * 功能：将鼠标移动到窗口右侧区域
 ********************************************************************/
void MoveMouseToWindowRight(HWND hWnd)
{
    RECT r;
    GetWindowRect(hWnd, &r);
    int x = r.right - (r.right - r.left) / 5;
    int y = (r.top + r.bottom) / 2;
    SetCursorPos(x, y);
    Sleep(200);
}

/********************************************************************
 * 函数：MoveMouseToWindowRightTopThird
 * 功能：将鼠标移动到窗口右侧偏上1/3位置（靠近边缘）
 ********************************************************************/
void MoveMouseToWindowRightTopThird(HWND hWnd)
{
    RECT r;
    GetWindowRect(hWnd, &r);
    int width = r.right - r.left;
    int height = r.bottom - r.top;

    // 水平位置：右侧边缘，保留小边距
    int margin = max(8, width / 40);
    int x = r.right - margin;

    // 垂直位置：窗口高度1/3处
    int y = r.top + height / 3;

    SetCursorPos(x, y);
    Sleep(200);
}

/********************************************************************
 * 函数：ReadTextFromClipboard
 * 功能：从剪贴板读取文本（支持Unicode、ANSI、UTF-8、HTML、文件路径）
 * 参数：outText - 输出读取到的宽字符串
 * 返回：成功true，失败false
 ********************************************************************/
bool ReadTextFromClipboard(std::wstring& outText)
{
    outText.clear();
    if (!OpenClipboard(NULL)) // 打开剪贴板
        return false;

    // 优先读取 Unicode 文本
    HANDLE hData = GetClipboardData(CF_UNICODETEXT);
    if (hData)
    {
        wchar_t* pData = (wchar_t*)GlobalLock(hData);
        if (pData)
        {
            outText = pData;
        }
        GlobalUnlock(hData);
        CloseClipboard();
        return !outText.empty();
    }

    // 备选：读取 ANSI/UTF-8 文本
    hData = GetClipboardData(CF_TEXT);
    if (hData)
    {
        SIZE_T rawSize = GlobalSize(hData);
        char* pData = (char*)GlobalLock(hData);
        if (pData && rawSize > 0)
        {
            // 写入原始数据用于调试
            FILE* fb = nullptr;
            errno_t ferr = fopen_s(&fb, "clipboard_raw.bin", "wb");
            if (ferr == 0 && fb) {
                fwrite(pData, 1, rawSize, fb);
                fclose(fb);
                DebugLog("[剪贴板] 已保存原始数据到 clipboard_raw.bin (大小=%llu)", (unsigned long long)rawSize);
            }
            std::string s(pData, pData + rawSize);
            GlobalUnlock(hData);
            CloseClipboard();

            // UTF-8 检测函数
            auto is_valid_utf8 = [](const std::string& str) -> bool {
                const unsigned char* bytes = (const unsigned char*)str.c_str();
                size_t len = str.size();
                size_t i = 0;
                while (i < len) {
                    unsigned char c = bytes[i];
                    if (c <= 0x7F) {
                        i++;
                        continue;
                    }
                    else if ((c >> 5) == 0x6) {
                        if (i + 1 >= len) return false;
                        unsigned char c1 = bytes[i + 1];
                        if ((c1 >> 6) != 0x2) return false;
                        i += 2;
                    }
                    else if ((c >> 4) == 0xE) {
                        if (i + 2 >= len) return false;
                        unsigned char c1 = bytes[i + 1];
                        unsigned char c2 = bytes[i + 2];
                        if ((c1 >> 6) != 0x2 || (c2 >> 6) != 0x2) return false;
                        i += 3;
                    }
                    else if ((c >> 3) == 0x1E) {
                        if (i + 3 >= len) return false;
                        unsigned char c1 = bytes[i + 1];
                        unsigned char c2 = bytes[i + 2];
                        unsigned char c3 = bytes[i + 3];
                        if ((c1 >> 6) != 0x2 || (c2 >> 6) != 0x2 || (c3 >> 6) != 0x2) return false;
                        i += 4;
                    }
                    else {
                        return false;
                    }
                }
                return true;
                };

            // 处理 UTF-8 BOM
            if (s.size() >= 3 && (unsigned char)s[0] == 0xEF && (unsigned char)s[1] == 0xBB && (unsigned char)s[2] == 0xBF) {
                std::string t = s.substr(3);
                int len = MultiByteToWideChar(CP_UTF8, 0, t.c_str(), (int)t.size(), NULL, 0);
                if (len > 0) {
                    outText.assign(len, 0);
                    MultiByteToWideChar(CP_UTF8, 0, t.c_str(), (int)t.size(), &outText[0], len);
                    return !outText.empty();
                }
            }

            // 检测为 UTF-8 则直接解码
            if (is_valid_utf8(s)) {
                int len = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), NULL, 0);
                if (len > 0) {
                    outText.assign(len, 0);
                    MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), &outText[0], len);
                    return !outText.empty();
                }
            }

            // 兜底：使用系统默认编码 ANSI
            int len = MultiByteToWideChar(CP_ACP, 0, s.c_str(), (int)s.size(), NULL, 0);
            if (len > 0)
            {
                outText.assign(len, 0);
                MultiByteToWideChar(CP_ACP, 0, s.c_str(), (int)s.size(), &outText[0], len);
                return !outText.empty();
            }
        }
    }

    // 读取 HTML 格式内容
    UINT cf_html = RegisterClipboardFormatA("HTML Format");
    if (cf_html != 0) {
        hData = GetClipboardData(cf_html);
        if (hData) {
            SIZE_T rawSize = GlobalSize(hData);
            char* pData = (char*)GlobalLock(hData);
            if (pData && rawSize > 0) {
                FILE* fh = nullptr;
                if (fopen_s(&fh, "clipboard_html.html", "wb") == 0 && fh) {
                    fwrite(pData, 1, rawSize, fh);
                    fclose(fh);
                    DebugLog("[剪贴板] 已保存HTML数据到 clipboard_html.html");
                }
                std::string s(pData, pData + rawSize);
                GlobalUnlock(hData);
                CloseClipboard();
                int len = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), NULL, 0);
                if (len > 0) {
                    outText.assign(len, 0);
                    MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), &outText[0], len);
                    return !outText.empty();
                }
            }
        }
    }

    // 读取复制的文件路径（CF_HDROP）
    hData = GetClipboardData(CF_HDROP);
    if (hData) {
        HDROP hDrop = (HDROP)hData;
        UINT count = DragQueryFileW(hDrop, 0xFFFFFFFF, NULL, 0);
        if (count > 0) {
            wchar_t fname[MAX_PATH];
            if (DragQueryFileW(hDrop, 0, fname, MAX_PATH)) {
                outText = fname;
                CloseClipboard();
                return true;
            }
        }
    }

    CloseClipboard();
    return false;
}

/********************************************************************
 * 函数：MouseScrollDown
 * 功能：模拟鼠标滚轮向下滚动一格
 ********************************************************************/
void MouseScrollDown()
{
    mouse_event(MOUSEEVENTF_WHEEL, 0, 0, -120, 0);
    Sleep(100);
}

/********************************************************************
 * 函数：IsKeyPress_P
 * 功能：检测 P 键是否正在被按下
 * 返回：按下返回true，否则false
 ********************************************************************/
bool IsKeyPress_P()
{
    return (GetAsyncKeyState('P') & 0x8000) != 0;
}

/********************************************************************
 * 函数：SendEscapeKey
 * 功能：模拟按下并松开 ESC 键
 ********************************************************************/
void SendEscapeKey()
{
    INPUT k[2] = { 0 };
    k[0].type = INPUT_KEYBOARD; k[0].ki.wVk = VK_ESCAPE; // 按下
    k[1].type = INPUT_KEYBOARD; k[1].ki.wVk = VK_ESCAPE; k[1].ki.dwFlags = KEYEVENTF_KEYUP; // 松开
    SendInput(2, k, sizeof(INPUT));
    Sleep(200);
}

/********************************************************************
 * 函数：ResetClipboard
 * 功能：清空剪贴板内容
 ********************************************************************/
void ResetClipboard()
{
    if (OpenClipboard(NULL)) {
        EmptyClipboard();
        CloseClipboard();
    }
    Sleep(100);
}

/********************************************************************
 * 函数：calc_similarity
 * 功能：计算两个浮点向量的余弦相似度（用于文本/特征匹配）
 * 参数：vec1/vec2 - 输入向量
 * 返回：相似度 [-1,1]，值越接近1越相似
 ********************************************************************/
float calc_similarity(const std::vector<float>& vec1, const std::vector<float>& vec2)
{
    // 合法性检查
    if (vec1.empty() || vec2.empty() || vec1.size() != vec2.size())
    {
        printf("[错误] 向量相似度计算失败：向量为空或长度不匹配 (vec1=%d, vec2=%d)\n",
            (int)vec1.size(), (int)vec2.size());
        return 0.0f;
    }

    float dot_product = 0.0f; // 点积
    float norm1 = 0.0f;      // 向量1模长平方
    float norm2 = 0.0f;      // 向量2模长平方

    for (size_t i = 0; i < vec1.size(); i++)
    {
        dot_product += vec1[i] * vec2[i];
        norm1 += vec1[i] * vec1[i];
        norm2 += vec2[i] * vec2[i];
    }

    // 零向量判断
    if (norm1 < 1e-6f || norm2 < 1e-6f)
    {
        printf("[错误] 向量模长为0，无法计算相似度\n");
        return 0.0f;
    }

    // 余弦相似度公式：cosθ = 点积 / (模1 * 模2)
    float similarity = dot_product / ((float)sqrt(norm1) * (float)sqrt(norm2));

    // 调试日志
    DebugLog("[相似度] 点积=%.6f, 模1=%.6f, 模2=%.6f, 结果=%.6f",
        dot_product, norm1, norm2, similarity);

    // 值域限制 [-1,1]
    if (similarity < -1.0f) similarity = -1.0f;
    if (similarity > 1.0f) similarity = 1.0f;

    return similarity;
}

/********************************************************************
 * 函数：GetAppDir
 * 功能：获取当前程序所在目录（不含文件名）
 * 返回：程序目录宽字符串
 ********************************************************************/
std::wstring GetAppDir()
{
    wchar_t buf[MAX_PATH];
    GetModuleFileNameW(NULL, buf, MAX_PATH); // 获取exe完整路径
    PathRemoveFileSpecW(buf); // 移除文件名，保留目录
    return buf;
}

/********************************************************************
 * 函数：ReadTemplateFile
 * 功能：读取程序目录下 data/template.txt 模板文件（UTF-8编码）
 * 返回：文件内容宽字符串
 ********************************************************************/
std::wstring ReadTemplateFile()
{
    wchar_t buf[MAX_PATH];
    GetModuleFileNameW(NULL, buf, MAX_PATH);
    PathRemoveFileSpecW(buf);
    std::wstring p = buf;
    p += L"\\data\\template.txt";

    // 二进制读取避免换行符问题
    std::ifstream f(p, std::ios::binary);
    if (!f) return L"";

    std::string b((std::istreambuf_iterator<char>(f)), {});
    f.close();

    // 去除UTF-8 BOM
    if (b.size() >= 3 && (unsigned char)b[0] == 0xEF && b[1] == 0xBB && b[2] == 0xBF)
        b = b.substr(3);

    // 转宽字符
    int l = MultiByteToWideChar(CP_UTF8, 0, b.data(), (int)b.size(), 0, 0);
    std::wstring r(l, 0);
    MultiByteToWideChar(CP_UTF8, 0, b.data(), (int)b.size(), &r[0], l);
    return r;
}